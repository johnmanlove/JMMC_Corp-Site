(function( $ ) {

    // Add Color Picker to all inputs that have 'color-field' class
    jQuery(document).ready(function($){
        $('.wpcufpn_colorPicker').wpColorPicker();
    });

})( jQuery );