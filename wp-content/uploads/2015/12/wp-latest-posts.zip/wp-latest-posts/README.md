WP Latest Post
==============

Updates :
---------
Revision 3.5.0:
* Add codemirror, Offset parameter, set order to random

Revision 3.4.0:
* Generate a PHP code in order to insert a news bloc in page template file

Revision 3.3.0:
* Add new default theme

Revision 3.2.1:
* Fix first image size

Revision 3.2.0:
* Add new portfolio theme

Revision 3.1.4:
* Fix notice PHP message

Revision 3.1.3:
* Fix notice PHP message

Revision 3.1.2:
* Fix Enqueue style and script (Fusion Page Builder compatibility)

Revision 3.1.1:
* Best Way to enqueue style (header) and script (footer)

Revision 3.1.0:
* Add multiple settings in animation block

Revision 3.0.9:
* Add htmlentities in "alt" attribute

Revision 3.0.8:
* Add 'Post content' or 'Excerpt content' settings in advanced tabs

Revision 3.0.7:
* Enable Crop text in grid theme

Revision 3.0.6:
* Add List in Pages filter

Revision 3.0.5: 
* Fix Order filter
* Add Custom CSS Field
* Add After/before Date created filter

Revision 3.0.4:
* Change Image default

Revision 3.0.3:
* Remove Filter Text Field
* Fix JS Issue Admin

Revision 3.0.2:
* Category display fix issue #2

Revision 3.0.1:
* Custom Taxonomies and Terms of CPT fix issue #1

Revision 3.0.0:
* Custom Post Type Core Include

Revision 2.0.9:
 * remove Uniform CSS and fix JS bug with 4.1

Revision 2.0.8:
 * Add nice 'promote' in about page

Revision 2.0.7:
 * Fix closing <div>
 * wp-latest-posts-pro-addon become wp-latest-posts-addon
 
Revision 2.0.6:
 * Add Tag Source !

Revision 2.0.5:
 * Remove ugly code

Revision 2.0.4:
 * Fix Category Query POST

Revision 2.0.3:
 * Refund the source type image (first image work now!).

Revision 2.0.2:
 * Add a good close div.
